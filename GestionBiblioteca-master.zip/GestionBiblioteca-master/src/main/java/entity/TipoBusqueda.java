package entity;

public enum TipoBusqueda {TODOS,OR}
