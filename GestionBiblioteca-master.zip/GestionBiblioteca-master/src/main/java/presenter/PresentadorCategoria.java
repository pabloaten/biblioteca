package presenter;

import controllers.CategoriaController;

/**
 * Clase que actúa como presentador para la entidad 'Categoria', gestionando la interacción entre la vista y el controlador.
 */
public class PresentadorCategoria {
    private CategoriaController categoriaController;
    private VistaCategoria vistaCategoria;

    /**
     * Constructor que inicializa el PresentadorCategoria con un controlador y una vista.
     *
     * @param categoriaController Controlador de la entidad 'Categoria'.
     * @param vistaCategoria      Vista asociada al presentador.
     */
    public PresentadorCategoria(CategoriaController categoriaController, VistaCategoria vistaCategoria) {
        this.categoriaController = categoriaController;
        this.vistaCategoria = vistaCategoria;
    }

    /**
     * Elimina una categoría utilizando el controlador.
     *
     * @throws Exception Si hay problemas durante el proceso de eliminación.
     */
    public void borra() throws Exception {
        categoriaController.borrar(vistaCategoria.getCategoria().getId());
    }

    /**
     * Inserta una nueva categoría utilizando el controlador.
     *
     * @throws Exception Si hay problemas durante el proceso de inserción.
     */
    public void inserta() throws Exception {
        categoriaController.inserta(vistaCategoria.getCategoria());
    }

    /**
     * Modifica una categoría existente utilizando el controlador.
     *
     * @throws Exception Si hay problemas durante el proceso de modificación.
     */
    public void modifica() throws Exception {
        categoriaController.modificar(vistaCategoria.getCategoria());
    }

    /**
     * Obtiene y muestra todas las categorías utilizando el controlador y actualiza la vista correspondiente.
     *
     * @throws Exception Si hay problemas durante el proceso de obtención de las categorías.
     */
    public void listaAllCategorias() throws Exception {
        VistaCategorias vistaCategorias = (VistaCategorias) vistaCategoria;
        vistaCategorias.setCategorias(categoriaController.leerTodasCategorias());
    }
}
