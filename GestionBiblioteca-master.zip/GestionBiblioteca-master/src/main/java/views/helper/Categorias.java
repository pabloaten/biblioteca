package views.helper;

import entity.CategoriaDTO;
import controllers.CategoriaController;
import presenter.PresentadorCategoria;
import views.FichaCategoria;
import views.ListaCategorias;
/**
 * Clase de utilidad que proporciona métodos estáticos para interactuar con categorías.
 * Permite obtener listas de categorías y fichas de categorías utilizando controladores y presentadores.
 */
public class Categorias {
    /**
     * Obtiene una lista de categorías.
     *
     * @return Lista de categorías.
     * @throws Exception Si ocurre un error durante la obtención de la lista de categorías.
     */
    public static ListaCategorias listaCategorias() throws Exception {
        CategoriaController categoriaController = new CategoriaController();
        ListaCategorias listaCategorias=new ListaCategorias();
        PresentadorCategoria presentadorCategoria=new PresentadorCategoria(categoriaController,listaCategorias);
        listaCategorias.setPresentador(presentadorCategoria);
        listaCategorias.lanzar();
        return listaCategorias;
    }

    /**
     * Obtiene una ficha de categoría para la categoría proporcionada.
     *
     * @param categoria Categoría para la cual se obtendrá la ficha.
     * @return Ficha de categoría.
     * @throws Exception Si ocurre un error durante la obtención de la ficha de categoría.
     */
    public static FichaCategoria fichaCategoria(CategoriaDTO categoria) throws Exception {
        CategoriaController categoriaController = new CategoriaController();
        FichaCategoria fichaCategoria=new FichaCategoria(categoria);
        PresentadorCategoria presentadorCategoria=new PresentadorCategoria(categoriaController,fichaCategoria);
        fichaCategoria.setPresentador(presentadorCategoria);
        fichaCategoria.lanzar();
        return fichaCategoria;
    }
}
