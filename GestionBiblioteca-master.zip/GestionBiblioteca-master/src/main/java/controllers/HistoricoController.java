package controllers;

public class HistoricoController {
}
